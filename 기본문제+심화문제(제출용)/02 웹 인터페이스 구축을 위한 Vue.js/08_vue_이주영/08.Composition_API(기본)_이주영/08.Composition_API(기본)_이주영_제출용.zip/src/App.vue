<template>
  <div>
    <Calc />
  </div>
</template>

<script>
// 슬라이드4: App.vue를다음과같이정의하고, Calc 컴포넌트가 올바르게 동작하는지 확인하세요. -->
//import Calc from './components/Calc.vue';

// 슬라이드6: Calc2 컴포넌트를 사용하도록 App.vue를수정하세요.
//import Calc from './components/Calc2.vue';

// 슬라이드8: Calc3 컴포넌트를 사용하도록 App.vue를수정하세요.
// import Calc from './components/Calc3.vue'; 

// 슬라이드10: Calc4 컴포넌트를 사용하도록 App.vue를수정하세요.
// import Calc from './components/Calc4.vue'; 

// 슬라이드12: Calc5 컴포넌트를사용하도록App.vue를수정하세요.
import Calc from './components/Calc5.vue'
export default {
  name: 'App',
  components: { Calc },
};
</script>
