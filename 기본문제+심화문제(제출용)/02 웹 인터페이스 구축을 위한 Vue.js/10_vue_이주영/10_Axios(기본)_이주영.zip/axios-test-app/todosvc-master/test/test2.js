import { getTodoList } from '../src/tododao';

console.log(getTodoList({ owner:'gdhong' }))
