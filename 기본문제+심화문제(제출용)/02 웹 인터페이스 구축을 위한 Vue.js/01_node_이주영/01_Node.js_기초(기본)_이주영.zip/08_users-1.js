//다음 모듈에서 module.exports로 user1과 user2를 내보내기 하세요.

const user1 = 'Kim';
const user2 = 'Lee';
const user3 = 'Choi';

module.exports = {user1, user2};