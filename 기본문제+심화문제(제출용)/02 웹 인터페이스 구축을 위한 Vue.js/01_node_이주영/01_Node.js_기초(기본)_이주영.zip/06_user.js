//아래의 모듈에서 module.exports를 이용해서 내보내기 하세요.

const user = '홍길동';

module.exports = user;