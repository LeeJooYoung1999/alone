//앞의 두 모듈을 가져와서 다음과 같이 출력되도록 완성하세요.
//홍길동님, 안녕하세요?

const user = require("./06_user");
const hello = require("./06_hello");

hello(user);
